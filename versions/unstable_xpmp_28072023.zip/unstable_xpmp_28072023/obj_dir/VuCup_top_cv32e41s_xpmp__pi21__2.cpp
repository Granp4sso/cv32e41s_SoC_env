// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See VuCup_top.h for the primary calling header

#include "VuCup_top_cv32e41s_xpmp__pi21.h"
#include "VuCup_top__Syms.h"

#include "verilated_dpi.h"

VL_INLINE_OPT void VuCup_top_cv32e41s_xpmp__pi21::_combo__TOP__uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__mpu_i__DOT__xpmp__DOT__xpmp_i__13(VuCup_top__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+                  VuCup_top_cv32e41s_xpmp__pi21::_combo__TOP__uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__mpu_i__DOT__xpmp__DOT__xpmp_i__13\n"); );
    VuCup_top* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt 
        = ((0xfffeU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt)) 
           | ((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                         << 7U) | (
                                                   vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                   >> 0x19U)))) 
                       >> 2U)) < ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x42U] 
                                   << 0x1aU) | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x41U] 
                                                >> 6U))));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt 
        = ((0xfffdU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt)) 
           | (((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                          << 7U) | 
                                         (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                          >> 0x19U)))) 
                        >> 2U)) < ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x43U] 
                                    << 0x18U) | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x42U] 
                                                 >> 8U))) 
              << 1U));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt 
        = ((0xfffbU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt)) 
           | (((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                          << 7U) | 
                                         (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                          >> 0x19U)))) 
                        >> 2U)) < ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x44U] 
                                    << 0x16U) | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x43U] 
                                                 >> 0xaU))) 
              << 2U));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt 
        = ((0xfff7U & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt)) 
           | (((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                          << 7U) | 
                                         (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                          >> 0x19U)))) 
                        >> 2U)) < ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x45U] 
                                    << 0x14U) | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x44U] 
                                                 >> 0xcU))) 
              << 3U));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt 
        = ((0xffefU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt)) 
           | (((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                          << 7U) | 
                                         (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                          >> 0x19U)))) 
                        >> 2U)) < ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x46U] 
                                    << 0x12U) | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x45U] 
                                                 >> 0xeU))) 
              << 4U));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt 
        = ((0xffdfU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt)) 
           | (((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                          << 7U) | 
                                         (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                          >> 0x19U)))) 
                        >> 2U)) < ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x47U] 
                                    << 0x10U) | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x46U] 
                                                 >> 0x10U))) 
              << 5U));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt 
        = ((0xffbfU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt)) 
           | (((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                          << 7U) | 
                                         (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                          >> 0x19U)))) 
                        >> 2U)) < ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x48U] 
                                    << 0xeU) | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x47U] 
                                                >> 0x12U))) 
              << 6U));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt 
        = ((0xff7fU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt)) 
           | (((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                          << 7U) | 
                                         (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                          >> 0x19U)))) 
                        >> 2U)) < ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x49U] 
                                    << 0xcU) | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x48U] 
                                                >> 0x14U))) 
              << 7U));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt 
        = ((0xfeffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt)) 
           | (((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                          << 7U) | 
                                         (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                          >> 0x19U)))) 
                        >> 2U)) < ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x4aU] 
                                    << 0xaU) | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x49U] 
                                                >> 0x16U))) 
              << 8U));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt 
        = ((0xfdffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt)) 
           | (((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                          << 7U) | 
                                         (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                          >> 0x19U)))) 
                        >> 2U)) < ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x4bU] 
                                    << 8U) | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x4aU] 
                                              >> 0x18U))) 
              << 9U));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt 
        = ((0xfbffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt)) 
           | (((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                          << 7U) | 
                                         (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                          >> 0x19U)))) 
                        >> 2U)) < ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x4cU] 
                                    << 6U) | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x4bU] 
                                              >> 0x1aU))) 
              << 0xaU));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt 
        = ((0xf7ffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt)) 
           | (((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                          << 7U) | 
                                         (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                          >> 0x19U)))) 
                        >> 2U)) < ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x4dU] 
                                    << 4U) | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x4cU] 
                                              >> 0x1cU))) 
              << 0xbU));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt 
        = ((0xefffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt)) 
           | (((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                          << 7U) | 
                                         (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                          >> 0x19U)))) 
                        >> 2U)) < ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x4eU] 
                                    << 2U) | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x4dU] 
                                              >> 0x1eU))) 
              << 0xcU));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt 
        = ((0xdfffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt)) 
           | (((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                          << 7U) | 
                                         (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                          >> 0x19U)))) 
                        >> 2U)) < vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x4fU]) 
              << 0xdU));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt 
        = ((0xbfffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt)) 
           | (((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                          << 7U) | 
                                         (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                          >> 0x19U)))) 
                        >> 2U)) < ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x51U] 
                                    << 0x1eU) | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x50U] 
                                                 >> 2U))) 
              << 0xeU));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt 
        = ((0x7fffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt)) 
           | (((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                          << 7U) | 
                                         (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                          >> 0x19U)))) 
                        >> 2U)) < ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x52U] 
                                    << 0x1cU) | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x51U] 
                                                 >> 4U))) 
              << 0xfU));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check 
        = ((0xfffeU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check)) 
           | ((((0U == ((0x1000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                         ? 1U : 2U)) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                        >> 6U)) | (
                                                   (1U 
                                                    == 
                                                    ((0x1000000U 
                                                      & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                      ? 1U
                                                      : 2U)) 
                                                   & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                                      >> 5U))) 
              | ((2U == ((0x1000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                          ? 1U : 2U)) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                         >> 4U))));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check 
        = ((0xfffdU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check)) 
           | (((0x7fffeU & (((0U == ((0x1000000U & 
                                      vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                      ? 1U : 2U)) << 1U) 
                            & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                               >> 0xdU))) | (0xffffeU 
                                             & (((1U 
                                                  == 
                                                  ((0x1000000U 
                                                    & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                    ? 1U
                                                    : 2U)) 
                                                 << 1U) 
                                                & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                                   >> 0xcU)))) 
              | (0x1ffffeU & (((2U == ((0x1000000U 
                                        & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                        ? 1U : 2U)) 
                               << 1U) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                         >> 0xbU)))));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check 
        = ((0xfffbU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check)) 
           | (((0xffcU & (((0U == ((0x1000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                    ? 1U : 2U)) << 2U) 
                          & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                             >> 0x14U))) | (0x1ffcU 
                                            & (((1U 
                                                 == 
                                                 ((0x1000000U 
                                                   & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                   ? 1U
                                                   : 2U)) 
                                                << 2U) 
                                               & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                                  >> 0x13U)))) 
              | (0x3ffcU & (((2U == ((0x1000000U & 
                                      vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                      ? 1U : 2U)) << 2U) 
                            & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                               >> 0x12U)))));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check 
        = ((0xfff7U & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check)) 
           | (((0x18U & (((0U == ((0x1000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                   ? 1U : 2U)) << 3U) 
                         & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                            >> 0x1bU))) | (0x38U & 
                                           (((1U == 
                                              ((0x1000000U 
                                                & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                ? 1U
                                                : 2U)) 
                                             << 3U) 
                                            & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                               >> 0x1aU)))) 
              | (0x78U & (((2U == ((0x1000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                    ? 1U : 2U)) << 3U) 
                          & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                             >> 0x19U)))));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check 
        = ((0xffefU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check)) 
           | (((0x3ffffff0U & (((0U == ((0x1000000U 
                                         & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                         ? 1U : 2U)) 
                                << 4U) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                          >> 2U))) 
               | (0x7ffffff0U & (((1U == ((0x1000000U 
                                           & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                           ? 1U : 2U)) 
                                  << 4U) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                            >> 1U)))) 
              | (0xfffffff0U & (((2U == ((0x1000000U 
                                          & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                          ? 1U : 2U)) 
                                 << 4U) & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U]))));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check 
        = ((0xffdfU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check)) 
           | (((0x7fffe0U & (((0U == ((0x1000000U & 
                                       vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                       ? 1U : 2U)) 
                              << 5U) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                        >> 9U))) | 
               (0xffffe0U & (((1U == ((0x1000000U & 
                                       vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                       ? 1U : 2U)) 
                              << 5U) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                        >> 8U)))) | 
              (0x1ffffe0U & (((2U == ((0x1000000U & 
                                       vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                       ? 1U : 2U)) 
                              << 5U) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                        >> 7U)))));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check 
        = ((0xffbfU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check)) 
           | (((0xffc0U & (((0U == ((0x1000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                     ? 1U : 2U)) << 6U) 
                           & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                              >> 0x10U))) | (0x1ffc0U 
                                             & (((1U 
                                                  == 
                                                  ((0x1000000U 
                                                    & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                    ? 1U
                                                    : 2U)) 
                                                 << 6U) 
                                                & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                                   >> 0xfU)))) 
              | (0x3ffc0U & (((2U == ((0x1000000U & 
                                       vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                       ? 1U : 2U)) 
                              << 6U) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                        >> 0xeU)))));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check 
        = ((0xff7fU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check)) 
           | (((0x180U & (((0U == ((0x1000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                    ? 1U : 2U)) << 7U) 
                          & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                             >> 0x17U))) | (0x380U 
                                            & (((1U 
                                                 == 
                                                 ((0x1000000U 
                                                   & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                   ? 1U
                                                   : 2U)) 
                                                << 7U) 
                                               & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                                  >> 0x16U)))) 
              | (0x780U & (((2U == ((0x1000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                     ? 1U : 2U)) << 7U) 
                           & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                              >> 0x15U)))));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check 
        = ((0xfeffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check)) 
           | (0xffffff00U & (((((0U == ((0x1000000U 
                                         & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                         ? 1U : 2U)) 
                                << 8U) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                          << 2U)) | 
                              (((1U == ((0x1000000U 
                                         & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                         ? 1U : 2U)) 
                                << 8U) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                          << 3U))) 
                             | (((2U == ((0x1000000U 
                                          & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                          ? 1U : 2U)) 
                                 << 8U) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                           << 4U)))));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check 
        = ((0xfdffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check)) 
           | (((0x7fffe00U & (((0U == ((0x1000000U 
                                        & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                        ? 1U : 2U)) 
                               << 9U) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                         >> 5U))) | 
               (0xffffe00U & (((1U == ((0x1000000U 
                                        & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                        ? 1U : 2U)) 
                               << 9U) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                         >> 4U)))) 
              | (0x1ffffe00U & (((2U == ((0x1000000U 
                                          & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                          ? 1U : 2U)) 
                                 << 9U) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                           >> 3U)))));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check 
        = ((0xfbffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check)) 
           | (((0xffc00U & (((0U == ((0x1000000U & 
                                      vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                      ? 1U : 2U)) << 0xaU) 
                            & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                               >> 0xcU))) | (0x1ffc00U 
                                             & (((1U 
                                                  == 
                                                  ((0x1000000U 
                                                    & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                    ? 1U
                                                    : 2U)) 
                                                 << 0xaU) 
                                                & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                                   >> 0xbU)))) 
              | (0x3ffc00U & (((2U == ((0x1000000U 
                                        & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                        ? 1U : 2U)) 
                               << 0xaU) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                           >> 0xaU)))));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check 
        = ((0xf7ffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check)) 
           | (((0x1800U & (((0U == ((0x1000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                     ? 1U : 2U)) << 0xbU) 
                           & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                              >> 0x13U))) | (0x3800U 
                                             & (((1U 
                                                  == 
                                                  ((0x1000000U 
                                                    & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                    ? 1U
                                                    : 2U)) 
                                                 << 0xbU) 
                                                & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                                   >> 0x12U)))) 
              | (0x7800U & (((2U == ((0x1000000U & 
                                      vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                      ? 1U : 2U)) << 0xbU) 
                            & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                               >> 0x11U)))));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check 
        = ((0xefffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check)) 
           | (0xfffff000U & (((((0U == ((0x1000000U 
                                         & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                         ? 1U : 2U)) 
                                << 0xcU) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                            << 6U)) 
                              | (((1U == ((0x1000000U 
                                           & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                           ? 1U : 2U)) 
                                  << 0xcU) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                              << 7U))) 
                             | (((2U == ((0x1000000U 
                                          & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                          ? 1U : 2U)) 
                                 << 0xcU) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                             << 8U)))));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check 
        = ((0xdfffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check)) 
           | (((0x7fffe000U & (((0U == ((0x1000000U 
                                         & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                         ? 1U : 2U)) 
                                << 0xdU) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                            >> 1U))) 
               | (0xffffe000U & (((1U == ((0x1000000U 
                                           & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                           ? 1U : 2U)) 
                                  << 0xdU) & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U]))) 
              | (0xffffe000U & (((2U == ((0x1000000U 
                                          & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                          ? 1U : 2U)) 
                                 << 0xdU) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                             << 1U)))));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check 
        = ((0xbfffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check)) 
           | (((0xffc000U & (((0U == ((0x1000000U & 
                                       vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                       ? 1U : 2U)) 
                              << 0xeU) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                          >> 8U))) 
               | (0x1ffc000U & (((1U == ((0x1000000U 
                                          & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                          ? 1U : 2U)) 
                                 << 0xeU) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                             >> 7U)))) 
              | (0x3ffc000U & (((2U == ((0x1000000U 
                                         & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                         ? 1U : 2U)) 
                                << 0xeU) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                            >> 6U)))));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check 
        = ((0x7fffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check)) 
           | (((0x18000U & (((0U == ((0x1000000U & 
                                      vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                      ? 1U : 2U)) << 0xfU) 
                            & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                               >> 0xfU))) | (0x38000U 
                                             & (((1U 
                                                  == 
                                                  ((0x1000000U 
                                                    & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                    ? 1U
                                                    : 2U)) 
                                                 << 0xfU) 
                                                & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                                   >> 0xeU)))) 
              | (0x78000U & (((2U == ((0x1000000U & 
                                       vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                       ? 1U : 2U)) 
                              << 0xfU) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                          >> 0xdU)))));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt 
        = ((0xfffeU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt)) 
           | ((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                         << 7U) | (
                                                   vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                   >> 0x19U)))) 
                       >> 2U)) > ((this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[1U] 
                                   << 0x1eU) | (this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[0U] 
                                                >> 2U))));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt 
        = ((0xfffdU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt)) 
           | (((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                          << 7U) | 
                                         (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                          >> 0x19U)))) 
                        >> 2U)) > ((this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[2U] 
                                    << 0x1cU) | (this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[1U] 
                                                 >> 4U))) 
              << 1U));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt 
        = ((0xfffbU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt)) 
           | (((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                          << 7U) | 
                                         (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                          >> 0x19U)))) 
                        >> 2U)) > ((this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[3U] 
                                    << 0x1aU) | (this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[2U] 
                                                 >> 6U))) 
              << 2U));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt 
        = ((0xfff7U & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt)) 
           | (((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                          << 7U) | 
                                         (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                          >> 0x19U)))) 
                        >> 2U)) > ((this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[4U] 
                                    << 0x18U) | (this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[3U] 
                                                 >> 8U))) 
              << 3U));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt 
        = ((0xffefU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt)) 
           | (((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                          << 7U) | 
                                         (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                          >> 0x19U)))) 
                        >> 2U)) > ((this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[5U] 
                                    << 0x16U) | (this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[4U] 
                                                 >> 0xaU))) 
              << 4U));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt 
        = ((0xffdfU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt)) 
           | (((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                          << 7U) | 
                                         (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                          >> 0x19U)))) 
                        >> 2U)) > ((this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[6U] 
                                    << 0x14U) | (this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[5U] 
                                                 >> 0xcU))) 
              << 5U));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt 
        = ((0xffbfU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt)) 
           | (((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                          << 7U) | 
                                         (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                          >> 0x19U)))) 
                        >> 2U)) > ((this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[7U] 
                                    << 0x12U) | (this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[6U] 
                                                 >> 0xeU))) 
              << 6U));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt 
        = ((0xff7fU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt)) 
           | (((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                          << 7U) | 
                                         (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                          >> 0x19U)))) 
                        >> 2U)) > ((this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[8U] 
                                    << 0x10U) | (this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[7U] 
                                                 >> 0x10U))) 
              << 7U));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt 
        = ((0xfeffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt)) 
           | (((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                          << 7U) | 
                                         (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                          >> 0x19U)))) 
                        >> 2U)) > ((this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[9U] 
                                    << 0xeU) | (this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[8U] 
                                                >> 0x12U))) 
              << 8U));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt 
        = ((0xfdffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt)) 
           | (((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                          << 7U) | 
                                         (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                          >> 0x19U)))) 
                        >> 2U)) > ((this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[0xaU] 
                                    << 0xcU) | (this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[9U] 
                                                >> 0x14U))) 
              << 9U));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt 
        = ((0xfbffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt)) 
           | (((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                          << 7U) | 
                                         (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                          >> 0x19U)))) 
                        >> 2U)) > ((this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[0xbU] 
                                    << 0xaU) | (this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[0xaU] 
                                                >> 0x16U))) 
              << 0xaU));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt 
        = ((0xf7ffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt)) 
           | (((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                          << 7U) | 
                                         (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                          >> 0x19U)))) 
                        >> 2U)) > ((this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[0xcU] 
                                    << 8U) | (this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[0xbU] 
                                              >> 0x18U))) 
              << 0xbU));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt 
        = ((0xefffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt)) 
           | (((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                          << 7U) | 
                                         (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                          >> 0x19U)))) 
                        >> 2U)) > ((this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[0xdU] 
                                    << 6U) | (this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[0xcU] 
                                              >> 0x1aU))) 
              << 0xcU));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt 
        = ((0xdfffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt)) 
           | (((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                          << 7U) | 
                                         (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                          >> 0x19U)))) 
                        >> 2U)) > ((this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[0xeU] 
                                    << 4U) | (this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[0xdU] 
                                              >> 0x1cU))) 
              << 0xdU));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt 
        = ((0xbfffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt)) 
           | (((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                          << 7U) | 
                                         (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                          >> 0x19U)))) 
                        >> 2U)) > ((this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[0xfU] 
                                    << 2U) | (this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[0xeU] 
                                              >> 0x1eU))) 
              << 0xeU));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt 
        = ((0x7fffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt)) 
           | (((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                          << 7U) | 
                                         (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                          >> 0x19U)))) 
                        >> 2U)) > this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[0x10U]) 
              << 0xfU));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq 
        = ((0xfffeU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq)) 
           | (((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                          << 7U) | 
                                         (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                          >> 0x19U)))) 
                        >> 2U)) & this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_addr_mask[0U]) 
              == (((this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[1U] 
                    << 0x1eU) | (this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[0U] 
                                 >> 2U)) & this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_addr_mask[0U])));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq 
        = ((0xfffdU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq)) 
           | ((((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                           << 7U) | 
                                          (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                           >> 0x19U)))) 
                         >> 2U)) & this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_addr_mask[1U]) 
               == (((this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[2U] 
                     << 0x1cU) | (this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[1U] 
                                  >> 4U)) & this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_addr_mask[1U])) 
              << 1U));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq 
        = ((0xfffbU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq)) 
           | ((((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                           << 7U) | 
                                          (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                           >> 0x19U)))) 
                         >> 2U)) & this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_addr_mask[2U]) 
               == (((this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[3U] 
                     << 0x1aU) | (this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[2U] 
                                  >> 6U)) & this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_addr_mask[2U])) 
              << 2U));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq 
        = ((0xfff7U & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq)) 
           | ((((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                           << 7U) | 
                                          (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                           >> 0x19U)))) 
                         >> 2U)) & this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_addr_mask[3U]) 
               == (((this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[4U] 
                     << 0x18U) | (this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[3U] 
                                  >> 8U)) & this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_addr_mask[3U])) 
              << 3U));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq 
        = ((0xffefU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq)) 
           | ((((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                           << 7U) | 
                                          (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                           >> 0x19U)))) 
                         >> 2U)) & this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_addr_mask[4U]) 
               == (((this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[5U] 
                     << 0x16U) | (this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[4U] 
                                  >> 0xaU)) & this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_addr_mask[4U])) 
              << 4U));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq 
        = ((0xffdfU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq)) 
           | ((((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                           << 7U) | 
                                          (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                           >> 0x19U)))) 
                         >> 2U)) & this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_addr_mask[5U]) 
               == (((this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[6U] 
                     << 0x14U) | (this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[5U] 
                                  >> 0xcU)) & this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_addr_mask[5U])) 
              << 5U));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq 
        = ((0xffbfU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq)) 
           | ((((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                           << 7U) | 
                                          (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                           >> 0x19U)))) 
                         >> 2U)) & this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_addr_mask[6U]) 
               == (((this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[7U] 
                     << 0x12U) | (this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[6U] 
                                  >> 0xeU)) & this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_addr_mask[6U])) 
              << 6U));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq 
        = ((0xff7fU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq)) 
           | ((((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                           << 7U) | 
                                          (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                           >> 0x19U)))) 
                         >> 2U)) & this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_addr_mask[7U]) 
               == (((this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[8U] 
                     << 0x10U) | (this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[7U] 
                                  >> 0x10U)) & this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_addr_mask[7U])) 
              << 7U));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq 
        = ((0xfeffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq)) 
           | ((((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                           << 7U) | 
                                          (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                           >> 0x19U)))) 
                         >> 2U)) & this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_addr_mask[8U]) 
               == (((this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[9U] 
                     << 0xeU) | (this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[8U] 
                                 >> 0x12U)) & this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_addr_mask[8U])) 
              << 8U));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq 
        = ((0xfdffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq)) 
           | ((((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                           << 7U) | 
                                          (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                           >> 0x19U)))) 
                         >> 2U)) & this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_addr_mask[9U]) 
               == (((this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[0xaU] 
                     << 0xcU) | (this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[9U] 
                                 >> 0x14U)) & this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_addr_mask[9U])) 
              << 9U));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq 
        = ((0xfbffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq)) 
           | ((((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                           << 7U) | 
                                          (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                           >> 0x19U)))) 
                         >> 2U)) & this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_addr_mask[0xaU]) 
               == (((this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[0xbU] 
                     << 0xaU) | (this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[0xaU] 
                                 >> 0x16U)) & this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_addr_mask[0xaU])) 
              << 0xaU));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq 
        = ((0xf7ffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq)) 
           | ((((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                           << 7U) | 
                                          (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                           >> 0x19U)))) 
                         >> 2U)) & this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_addr_mask[0xbU]) 
               == (((this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[0xcU] 
                     << 8U) | (this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[0xbU] 
                               >> 0x18U)) & this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_addr_mask[0xbU])) 
              << 0xbU));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq 
        = ((0xefffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq)) 
           | ((((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                           << 7U) | 
                                          (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                           >> 0x19U)))) 
                         >> 2U)) & this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_addr_mask[0xcU]) 
               == (((this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[0xdU] 
                     << 6U) | (this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[0xcU] 
                               >> 0x1aU)) & this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_addr_mask[0xcU])) 
              << 0xcU));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq 
        = ((0xdfffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq)) 
           | ((((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                           << 7U) | 
                                          (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                           >> 0x19U)))) 
                         >> 2U)) & this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_addr_mask[0xdU]) 
               == (((this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[0xeU] 
                     << 4U) | (this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[0xdU] 
                               >> 0x1cU)) & this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_addr_mask[0xdU])) 
              << 0xdU));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq 
        = ((0xbfffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq)) 
           | ((((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                           << 7U) | 
                                          (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                           >> 0x19U)))) 
                         >> 2U)) & this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_addr_mask[0xeU]) 
               == (((this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[0xfU] 
                     << 2U) | (this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[0xeU] 
                               >> 0x1eU)) & this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_addr_mask[0xeU])) 
              << 0xeU));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq 
        = ((0x7fffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq)) 
           | ((((IData)(((QData)((IData)(((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[2U] 
                                           << 7U) | 
                                          (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                           >> 0x19U)))) 
                         >> 2U)) & this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_addr_mask[0xfU]) 
               == (this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_start_addr[0x10U] 
                   & this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_addr_mask[0xfU])) 
              << 0xfU));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check 
        = (0xfffeU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check 
        = ((0xfffeU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check)) 
           | (1U & ((1U & ((~ (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                               >> 4U)) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                          >> 5U))) ? 
                    ((0x800U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U])
                      ? ((0x40U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U])
                          ? ((0U == ((0x1000000U & 
                                      vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                      ? 1U : 2U)) | 
                             ((2U == ((0x1000000U & 
                                       vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                       ? 1U : 2U)) 
                              & (3U == (3U & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                               << 0x10U) 
                                              | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                 >> 0x10U))))))
                          : (0U == ((0x1000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                     ? 1U : 2U))) : 
                     ((0x40U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U])
                       ? ((2U == ((0x1000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                   ? 1U : 2U)) | (1U 
                                                  == 
                                                  ((0x1000000U 
                                                    & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                    ? 1U
                                                    : 2U)))
                       : ((2U == ((0x1000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                   ? 1U : 2U)) | ((1U 
                                                   == 
                                                   ((0x1000000U 
                                                     & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                     ? 1U
                                                     : 2U)) 
                                                  & (3U 
                                                     == 
                                                     (3U 
                                                      & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                          << 0x10U) 
                                                         | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                            >> 0x10U))))))))
                     : ((1U & (((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                 >> 4U) & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                            >> 5U) 
                                           & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                              >> 6U))) 
                               & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                  >> 0xbU))) ? (2U 
                                                == 
                                                ((0x1000000U 
                                                  & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                  ? 1U
                                                  : 2U))
                         : ((3U == (3U & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                           << 0x10U) 
                                          | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                             >> 0x10U))))
                             ? ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                 >> 0xbU) & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check))
                             : ((~ (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                    >> 0xbU)) & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check)))))));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check 
        = (0xfffdU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check 
        = ((0xfffdU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check)) 
           | (2U & (((1U & ((~ (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                >> 0xcU)) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                             >> 0xdU)))
                      ? ((0x80000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U])
                          ? ((0x4000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U])
                              ? ((0U == ((0x1000000U 
                                          & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                          ? 1U : 2U)) 
                                 | ((2U == ((0x1000000U 
                                             & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                             ? 1U : 2U)) 
                                    & (3U == (3U & 
                                              ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                << 0x10U) 
                                               | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                  >> 0x10U))))))
                              : (0U == ((0x1000000U 
                                         & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                         ? 1U : 2U)))
                          : ((0x4000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U])
                              ? ((2U == ((0x1000000U 
                                          & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                          ? 1U : 2U)) 
                                 | (1U == ((0x1000000U 
                                            & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                            ? 1U : 2U)))
                              : ((2U == ((0x1000000U 
                                          & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                          ? 1U : 2U)) 
                                 | ((1U == ((0x1000000U 
                                             & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                             ? 1U : 2U)) 
                                    & (3U == (3U & 
                                              ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                << 0x10U) 
                                               | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                  >> 0x10U))))))))
                      : ((1U & (((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                  >> 0xcU) & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                               >> 0xdU) 
                                              & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                                 >> 0xeU))) 
                                & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                   >> 0x13U))) ? (2U 
                                                  == 
                                                  ((0x1000000U 
                                                    & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                    ? 1U
                                                    : 2U))
                          : ((3U == (3U & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                            << 0x10U) 
                                           | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                              >> 0x10U))))
                              ? ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                  >> 0x13U) & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                               >> 1U))
                              : ((~ (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                     >> 0x13U)) & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                   >> 1U))))) 
                    << 1U)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check 
        = (0xfffbU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check 
        = ((0xfffbU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check)) 
           | (4U & (((1U & ((~ (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                >> 0x14U)) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                              >> 0x15U)))
                      ? ((0x8000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U])
                          ? ((0x400000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U])
                              ? ((0U == ((0x1000000U 
                                          & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                          ? 1U : 2U)) 
                                 | ((2U == ((0x1000000U 
                                             & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                             ? 1U : 2U)) 
                                    & (3U == (3U & 
                                              ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                << 0x10U) 
                                               | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                  >> 0x10U))))))
                              : (0U == ((0x1000000U 
                                         & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                         ? 1U : 2U)))
                          : ((0x400000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U])
                              ? ((2U == ((0x1000000U 
                                          & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                          ? 1U : 2U)) 
                                 | (1U == ((0x1000000U 
                                            & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                            ? 1U : 2U)))
                              : ((2U == ((0x1000000U 
                                          & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                          ? 1U : 2U)) 
                                 | ((1U == ((0x1000000U 
                                             & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                             ? 1U : 2U)) 
                                    & (3U == (3U & 
                                              ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                << 0x10U) 
                                               | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                  >> 0x10U))))))))
                      : ((1U & (((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                  >> 0x14U) & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                                >> 0x15U) 
                                               & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                                  >> 0x16U))) 
                                & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                   >> 0x1bU))) ? (2U 
                                                  == 
                                                  ((0x1000000U 
                                                    & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                    ? 1U
                                                    : 2U))
                          : ((3U == (3U & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                            << 0x10U) 
                                           | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                              >> 0x10U))))
                              ? ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                  >> 0x1bU) & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                               >> 2U))
                              : ((~ (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                     >> 0x1bU)) & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                   >> 2U))))) 
                    << 2U)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check 
        = (0xfff7U & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check 
        = ((0xfff7U & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check)) 
           | (8U & (((1U & ((~ (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                >> 0x1cU)) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                              >> 0x1dU)))
                      ? ((8U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U])
                          ? ((0x40000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U])
                              ? ((0U == ((0x1000000U 
                                          & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                          ? 1U : 2U)) 
                                 | ((2U == ((0x1000000U 
                                             & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                             ? 1U : 2U)) 
                                    & (3U == (3U & 
                                              ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                << 0x10U) 
                                               | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                  >> 0x10U))))))
                              : (0U == ((0x1000000U 
                                         & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                         ? 1U : 2U)))
                          : ((0x40000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U])
                              ? ((2U == ((0x1000000U 
                                          & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                          ? 1U : 2U)) 
                                 | (1U == ((0x1000000U 
                                            & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                            ? 1U : 2U)))
                              : ((2U == ((0x1000000U 
                                          & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                          ? 1U : 2U)) 
                                 | ((1U == ((0x1000000U 
                                             & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                             ? 1U : 2U)) 
                                    & (3U == (3U & 
                                              ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                << 0x10U) 
                                               | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                  >> 0x10U))))))))
                      : ((1U & (((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                  >> 0x1cU) & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                                >> 0x1dU) 
                                               & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                                  >> 0x1eU))) 
                                & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                   >> 3U))) ? (2U == 
                                               ((0x1000000U 
                                                 & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                 ? 1U
                                                 : 2U))
                          : ((3U == (3U & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                            << 0x10U) 
                                           | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                              >> 0x10U))))
                              ? ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                  >> 3U) & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                            >> 3U))
                              : ((~ (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                     >> 3U)) & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                >> 3U))))) 
                    << 3U)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check 
        = (0xffefU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check 
        = ((0xffefU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check)) 
           | (0x10U & (((1U & ((~ (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                   >> 4U)) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                              >> 5U)))
                         ? ((0x800U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U])
                             ? ((0x40U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U])
                                 ? ((0U == ((0x1000000U 
                                             & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                             ? 1U : 2U)) 
                                    | ((2U == ((0x1000000U 
                                                & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                ? 1U
                                                : 2U)) 
                                       & (3U == (3U 
                                                 & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                     << 0x10U) 
                                                    | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                       >> 0x10U))))))
                                 : (0U == ((0x1000000U 
                                            & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                            ? 1U : 2U)))
                             : ((0x40U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U])
                                 ? ((2U == ((0x1000000U 
                                             & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                             ? 1U : 2U)) 
                                    | (1U == ((0x1000000U 
                                               & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                               ? 1U
                                               : 2U)))
                                 : ((2U == ((0x1000000U 
                                             & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                             ? 1U : 2U)) 
                                    | ((1U == ((0x1000000U 
                                                & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                ? 1U
                                                : 2U)) 
                                       & (3U == (3U 
                                                 & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                     << 0x10U) 
                                                    | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                       >> 0x10U))))))))
                         : ((1U & (((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                     >> 4U) & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                                >> 5U) 
                                               & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                                  >> 6U))) 
                                   & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                      >> 0xbU))) ? 
                            (2U == ((0x1000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                     ? 1U : 2U)) : 
                            ((3U == (3U & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                            << 0x10U) 
                                           | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                              >> 0x10U))))
                              ? ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                  >> 0xbU) & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                              >> 4U))
                              : ((~ (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                     >> 0xbU)) & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                  >> 4U))))) 
                       << 4U)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check 
        = (0xffdfU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check 
        = ((0xffdfU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check)) 
           | (0x20U & (((1U & ((~ (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                   >> 0xcU)) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                                >> 0xdU)))
                         ? ((0x80000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U])
                             ? ((0x4000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U])
                                 ? ((0U == ((0x1000000U 
                                             & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                             ? 1U : 2U)) 
                                    | ((2U == ((0x1000000U 
                                                & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                ? 1U
                                                : 2U)) 
                                       & (3U == (3U 
                                                 & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                     << 0x10U) 
                                                    | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                       >> 0x10U))))))
                                 : (0U == ((0x1000000U 
                                            & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                            ? 1U : 2U)))
                             : ((0x4000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U])
                                 ? ((2U == ((0x1000000U 
                                             & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                             ? 1U : 2U)) 
                                    | (1U == ((0x1000000U 
                                               & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                               ? 1U
                                               : 2U)))
                                 : ((2U == ((0x1000000U 
                                             & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                             ? 1U : 2U)) 
                                    | ((1U == ((0x1000000U 
                                                & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                ? 1U
                                                : 2U)) 
                                       & (3U == (3U 
                                                 & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                     << 0x10U) 
                                                    | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                       >> 0x10U))))))))
                         : ((1U & (((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                     >> 0xcU) & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                                  >> 0xdU) 
                                                 & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                                    >> 0xeU))) 
                                   & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                      >> 0x13U))) ? 
                            (2U == ((0x1000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                     ? 1U : 2U)) : 
                            ((3U == (3U & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                            << 0x10U) 
                                           | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                              >> 0x10U))))
                              ? ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                  >> 0x13U) & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                               >> 5U))
                              : ((~ (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                     >> 0x13U)) & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                   >> 5U))))) 
                       << 5U)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check 
        = (0xffbfU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check 
        = ((0xffbfU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check)) 
           | (0x40U & (((1U & ((~ (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                   >> 0x14U)) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                                 >> 0x15U)))
                         ? ((0x8000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U])
                             ? ((0x400000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U])
                                 ? ((0U == ((0x1000000U 
                                             & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                             ? 1U : 2U)) 
                                    | ((2U == ((0x1000000U 
                                                & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                ? 1U
                                                : 2U)) 
                                       & (3U == (3U 
                                                 & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                     << 0x10U) 
                                                    | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                       >> 0x10U))))))
                                 : (0U == ((0x1000000U 
                                            & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                            ? 1U : 2U)))
                             : ((0x400000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U])
                                 ? ((2U == ((0x1000000U 
                                             & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                             ? 1U : 2U)) 
                                    | (1U == ((0x1000000U 
                                               & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                               ? 1U
                                               : 2U)))
                                 : ((2U == ((0x1000000U 
                                             & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                             ? 1U : 2U)) 
                                    | ((1U == ((0x1000000U 
                                                & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                ? 1U
                                                : 2U)) 
                                       & (3U == (3U 
                                                 & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                     << 0x10U) 
                                                    | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                       >> 0x10U))))))))
                         : ((1U & (((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                     >> 0x14U) & ((
                                                   vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                                   >> 0x15U) 
                                                  & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                                     >> 0x16U))) 
                                   & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                      >> 0x1bU))) ? 
                            (2U == ((0x1000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                     ? 1U : 2U)) : 
                            ((3U == (3U & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                            << 0x10U) 
                                           | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                              >> 0x10U))))
                              ? ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                  >> 0x1bU) & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                               >> 6U))
                              : ((~ (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                     >> 0x1bU)) & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                   >> 6U))))) 
                       << 6U)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check 
        = (0xff7fU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check 
        = ((0xff7fU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check)) 
           | (0x80U & (((1U & ((~ (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                   >> 0x1cU)) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                                 >> 0x1dU)))
                         ? ((8U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U])
                             ? ((0x40000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U])
                                 ? ((0U == ((0x1000000U 
                                             & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                             ? 1U : 2U)) 
                                    | ((2U == ((0x1000000U 
                                                & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                ? 1U
                                                : 2U)) 
                                       & (3U == (3U 
                                                 & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                     << 0x10U) 
                                                    | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                       >> 0x10U))))))
                                 : (0U == ((0x1000000U 
                                            & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                            ? 1U : 2U)))
                             : ((0x40000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U])
                                 ? ((2U == ((0x1000000U 
                                             & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                             ? 1U : 2U)) 
                                    | (1U == ((0x1000000U 
                                               & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                               ? 1U
                                               : 2U)))
                                 : ((2U == ((0x1000000U 
                                             & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                             ? 1U : 2U)) 
                                    | ((1U == ((0x1000000U 
                                                & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                ? 1U
                                                : 2U)) 
                                       & (3U == (3U 
                                                 & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                     << 0x10U) 
                                                    | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                       >> 0x10U))))))))
                         : ((1U & (((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                     >> 0x1cU) & ((
                                                   vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                                   >> 0x1dU) 
                                                  & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                                     >> 0x1eU))) 
                                   & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                      >> 3U))) ? (2U 
                                                  == 
                                                  ((0x1000000U 
                                                    & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                    ? 1U
                                                    : 2U))
                             : ((3U == (3U & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                               << 0x10U) 
                                              | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                 >> 0x10U))))
                                 ? ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                     >> 3U) & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                               >> 7U))
                                 : ((~ (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                        >> 3U)) & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                   >> 7U))))) 
                       << 7U)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check 
        = (0xfeffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check 
        = ((0xfeffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check)) 
           | (0x100U & (((1U & ((~ (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                    >> 4U)) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                               >> 5U)))
                          ? ((0x800U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U])
                              ? ((0x40U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U])
                                  ? ((0U == ((0x1000000U 
                                              & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                              ? 1U : 2U)) 
                                     | ((2U == ((0x1000000U 
                                                 & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                 ? 1U
                                                 : 2U)) 
                                        & (3U == (3U 
                                                  & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                      << 0x10U) 
                                                     | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                        >> 0x10U))))))
                                  : (0U == ((0x1000000U 
                                             & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                             ? 1U : 2U)))
                              : ((0x40U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U])
                                  ? ((2U == ((0x1000000U 
                                              & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                              ? 1U : 2U)) 
                                     | (1U == ((0x1000000U 
                                                & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                ? 1U
                                                : 2U)))
                                  : ((2U == ((0x1000000U 
                                              & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                              ? 1U : 2U)) 
                                     | ((1U == ((0x1000000U 
                                                 & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                 ? 1U
                                                 : 2U)) 
                                        & (3U == (3U 
                                                  & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                      << 0x10U) 
                                                     | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                        >> 0x10U))))))))
                          : ((1U & (((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                      >> 4U) & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                                 >> 5U) 
                                                & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                                   >> 6U))) 
                                    & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                       >> 0xbU))) ? 
                             (2U == ((0x1000000U & 
                                      vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                      ? 1U : 2U)) : 
                             ((3U == (3U & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                             << 0x10U) 
                                            | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                               >> 0x10U))))
                               ? ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                   >> 0xbU) & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                               >> 8U))
                               : ((~ (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                      >> 0xbU)) & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                   >> 8U))))) 
                        << 8U)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check 
        = (0xfdffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check 
        = ((0xfdffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check)) 
           | (0x200U & (((1U & ((~ (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                    >> 0xcU)) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                                 >> 0xdU)))
                          ? ((0x80000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U])
                              ? ((0x4000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U])
                                  ? ((0U == ((0x1000000U 
                                              & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                              ? 1U : 2U)) 
                                     | ((2U == ((0x1000000U 
                                                 & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                 ? 1U
                                                 : 2U)) 
                                        & (3U == (3U 
                                                  & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                      << 0x10U) 
                                                     | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                        >> 0x10U))))))
                                  : (0U == ((0x1000000U 
                                             & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                             ? 1U : 2U)))
                              : ((0x4000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U])
                                  ? ((2U == ((0x1000000U 
                                              & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                              ? 1U : 2U)) 
                                     | (1U == ((0x1000000U 
                                                & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                ? 1U
                                                : 2U)))
                                  : ((2U == ((0x1000000U 
                                              & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                              ? 1U : 2U)) 
                                     | ((1U == ((0x1000000U 
                                                 & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                 ? 1U
                                                 : 2U)) 
                                        & (3U == (3U 
                                                  & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                      << 0x10U) 
                                                     | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                        >> 0x10U))))))))
                          : ((1U & (((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                      >> 0xcU) & ((
                                                   vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                                   >> 0xdU) 
                                                  & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                                     >> 0xeU))) 
                                    & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                       >> 0x13U))) ? 
                             (2U == ((0x1000000U & 
                                      vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                      ? 1U : 2U)) : 
                             ((3U == (3U & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                             << 0x10U) 
                                            | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                               >> 0x10U))))
                               ? ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                   >> 0x13U) & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                >> 9U))
                               : ((~ (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                      >> 0x13U)) & 
                                  ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                   >> 9U))))) << 9U)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check 
        = (0xfbffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check 
        = ((0xfbffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check)) 
           | (0x400U & (((1U & ((~ (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                    >> 0x14U)) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                                  >> 0x15U)))
                          ? ((0x8000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U])
                              ? ((0x400000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U])
                                  ? ((0U == ((0x1000000U 
                                              & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                              ? 1U : 2U)) 
                                     | ((2U == ((0x1000000U 
                                                 & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                 ? 1U
                                                 : 2U)) 
                                        & (3U == (3U 
                                                  & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                      << 0x10U) 
                                                     | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                        >> 0x10U))))))
                                  : (0U == ((0x1000000U 
                                             & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                             ? 1U : 2U)))
                              : ((0x400000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U])
                                  ? ((2U == ((0x1000000U 
                                              & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                              ? 1U : 2U)) 
                                     | (1U == ((0x1000000U 
                                                & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                ? 1U
                                                : 2U)))
                                  : ((2U == ((0x1000000U 
                                              & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                              ? 1U : 2U)) 
                                     | ((1U == ((0x1000000U 
                                                 & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                 ? 1U
                                                 : 2U)) 
                                        & (3U == (3U 
                                                  & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                      << 0x10U) 
                                                     | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                        >> 0x10U))))))))
                          : ((1U & (((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                      >> 0x14U) & (
                                                   (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                                    >> 0x15U) 
                                                   & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                                      >> 0x16U))) 
                                    & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                       >> 0x1bU))) ? 
                             (2U == ((0x1000000U & 
                                      vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                      ? 1U : 2U)) : 
                             ((3U == (3U & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                             << 0x10U) 
                                            | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                               >> 0x10U))))
                               ? ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                   >> 0x1bU) & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                >> 0xaU))
                               : ((~ (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                      >> 0x1bU)) & 
                                  ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                   >> 0xaU))))) << 0xaU)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check 
        = (0xf7ffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check 
        = ((0xf7ffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check)) 
           | (0x800U & (((1U & ((~ (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                    >> 0x1cU)) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                                  >> 0x1dU)))
                          ? ((8U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U])
                              ? ((0x40000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U])
                                  ? ((0U == ((0x1000000U 
                                              & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                              ? 1U : 2U)) 
                                     | ((2U == ((0x1000000U 
                                                 & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                 ? 1U
                                                 : 2U)) 
                                        & (3U == (3U 
                                                  & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                      << 0x10U) 
                                                     | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                        >> 0x10U))))))
                                  : (0U == ((0x1000000U 
                                             & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                             ? 1U : 2U)))
                              : ((0x40000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U])
                                  ? ((2U == ((0x1000000U 
                                              & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                              ? 1U : 2U)) 
                                     | (1U == ((0x1000000U 
                                                & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                ? 1U
                                                : 2U)))
                                  : ((2U == ((0x1000000U 
                                              & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                              ? 1U : 2U)) 
                                     | ((1U == ((0x1000000U 
                                                 & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                 ? 1U
                                                 : 2U)) 
                                        & (3U == (3U 
                                                  & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                      << 0x10U) 
                                                     | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                        >> 0x10U))))))))
                          : ((1U & (((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                      >> 0x1cU) & (
                                                   (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                                    >> 0x1dU) 
                                                   & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                                      >> 0x1eU))) 
                                    & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                       >> 3U))) ? (2U 
                                                   == 
                                                   ((0x1000000U 
                                                     & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                     ? 1U
                                                     : 2U))
                              : ((3U == (3U & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                << 0x10U) 
                                               | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                  >> 0x10U))))
                                  ? ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                      >> 3U) & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                >> 0xbU))
                                  : ((~ (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                         >> 3U)) & 
                                     ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                      >> 0xbU))))) 
                        << 0xbU)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check 
        = (0xefffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check 
        = ((0xefffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check)) 
           | (0x1000U & (((1U & ((~ (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                     >> 4U)) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                                >> 5U)))
                           ? ((0x800U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U])
                               ? ((0x40U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U])
                                   ? ((0U == ((0x1000000U 
                                               & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                               ? 1U
                                               : 2U)) 
                                      | ((2U == ((0x1000000U 
                                                  & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                  ? 1U
                                                  : 2U)) 
                                         & (3U == (3U 
                                                   & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                       << 0x10U) 
                                                      | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                         >> 0x10U))))))
                                   : (0U == ((0x1000000U 
                                              & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                              ? 1U : 2U)))
                               : ((0x40U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U])
                                   ? ((2U == ((0x1000000U 
                                               & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                               ? 1U
                                               : 2U)) 
                                      | (1U == ((0x1000000U 
                                                 & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                 ? 1U
                                                 : 2U)))
                                   : ((2U == ((0x1000000U 
                                               & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                               ? 1U
                                               : 2U)) 
                                      | ((1U == ((0x1000000U 
                                                  & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                  ? 1U
                                                  : 2U)) 
                                         & (3U == (3U 
                                                   & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                       << 0x10U) 
                                                      | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                         >> 0x10U))))))))
                           : ((1U & (((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                       >> 4U) & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                                  >> 5U) 
                                                 & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                                    >> 6U))) 
                                     & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                        >> 0xbU))) ? 
                              (2U == ((0x1000000U & 
                                       vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                       ? 1U : 2U)) : 
                              ((3U == (3U & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                              << 0x10U) 
                                             | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                >> 0x10U))))
                                ? ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                    >> 0xbU) & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                >> 0xcU))
                                : ((~ (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                       >> 0xbU)) & 
                                   ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                    >> 0xcU))))) << 0xcU)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check 
        = (0xdfffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check 
        = ((0xdfffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check)) 
           | (0x2000U & (((1U & ((~ (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                     >> 0xcU)) & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                                  >> 0xdU)))
                           ? ((0x80000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U])
                               ? ((0x4000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U])
                                   ? ((0U == ((0x1000000U 
                                               & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                               ? 1U
                                               : 2U)) 
                                      | ((2U == ((0x1000000U 
                                                  & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                  ? 1U
                                                  : 2U)) 
                                         & (3U == (3U 
                                                   & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                       << 0x10U) 
                                                      | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                         >> 0x10U))))))
                                   : (0U == ((0x1000000U 
                                              & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                              ? 1U : 2U)))
                               : ((0x4000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U])
                                   ? ((2U == ((0x1000000U 
                                               & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                               ? 1U
                                               : 2U)) 
                                      | (1U == ((0x1000000U 
                                                 & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                 ? 1U
                                                 : 2U)))
                                   : ((2U == ((0x1000000U 
                                               & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                               ? 1U
                                               : 2U)) 
                                      | ((1U == ((0x1000000U 
                                                  & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                  ? 1U
                                                  : 2U)) 
                                         & (3U == (3U 
                                                   & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                       << 0x10U) 
                                                      | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                         >> 0x10U))))))))
                           : ((1U & (((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                       >> 0xcU) & (
                                                   (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                                    >> 0xdU) 
                                                   & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                                      >> 0xeU))) 
                                     & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                        >> 0x13U)))
                               ? (2U == ((0x1000000U 
                                          & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                          ? 1U : 2U))
                               : ((3U == (3U & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                 << 0x10U) 
                                                | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                   >> 0x10U))))
                                   ? ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                       >> 0x13U) & 
                                      ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                       >> 0xdU)) : 
                                  ((~ (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                       >> 0x13U)) & 
                                   ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                    >> 0xdU))))) << 0xdU)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check 
        = (0xbfffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check 
        = ((0xbfffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check)) 
           | (0x4000U & (((1U & ((~ (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                     >> 0x14U)) & (
                                                   vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                                   >> 0x15U)))
                           ? ((0x8000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U])
                               ? ((0x400000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U])
                                   ? ((0U == ((0x1000000U 
                                               & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                               ? 1U
                                               : 2U)) 
                                      | ((2U == ((0x1000000U 
                                                  & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                  ? 1U
                                                  : 2U)) 
                                         & (3U == (3U 
                                                   & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                       << 0x10U) 
                                                      | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                         >> 0x10U))))))
                                   : (0U == ((0x1000000U 
                                              & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                              ? 1U : 2U)))
                               : ((0x400000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U])
                                   ? ((2U == ((0x1000000U 
                                               & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                               ? 1U
                                               : 2U)) 
                                      | (1U == ((0x1000000U 
                                                 & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                 ? 1U
                                                 : 2U)))
                                   : ((2U == ((0x1000000U 
                                               & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                               ? 1U
                                               : 2U)) 
                                      | ((1U == ((0x1000000U 
                                                  & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                  ? 1U
                                                  : 2U)) 
                                         & (3U == (3U 
                                                   & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                       << 0x10U) 
                                                      | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                         >> 0x10U))))))))
                           : ((1U & (((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                       >> 0x14U) & 
                                      ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                        >> 0x15U) & 
                                       (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                        >> 0x16U))) 
                                     & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                        >> 0x1bU)))
                               ? (2U == ((0x1000000U 
                                          & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                          ? 1U : 2U))
                               : ((3U == (3U & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                 << 0x10U) 
                                                | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                   >> 0x10U))))
                                   ? ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                       >> 0x1bU) & 
                                      ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                       >> 0xeU)) : 
                                  ((~ (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                       >> 0x1bU)) & 
                                   ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                    >> 0xeU))))) << 0xeU)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check 
        = (0x7fffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check 
        = ((0x7fffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check)) 
           | (0x8000U & (((1U & ((~ (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                     >> 0x1cU)) & (
                                                   vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                                   >> 0x1dU)))
                           ? ((8U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x89U])
                               ? ((0x40000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U])
                                   ? ((0U == ((0x1000000U 
                                               & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                               ? 1U
                                               : 2U)) 
                                      | ((2U == ((0x1000000U 
                                                  & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                  ? 1U
                                                  : 2U)) 
                                         & (3U == (3U 
                                                   & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                       << 0x10U) 
                                                      | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                         >> 0x10U))))))
                                   : (0U == ((0x1000000U 
                                              & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                              ? 1U : 2U)))
                               : ((0x40000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U])
                                   ? ((2U == ((0x1000000U 
                                               & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                               ? 1U
                                               : 2U)) 
                                      | (1U == ((0x1000000U 
                                                 & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                 ? 1U
                                                 : 2U)))
                                   : ((2U == ((0x1000000U 
                                               & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                               ? 1U
                                               : 2U)) 
                                      | ((1U == ((0x1000000U 
                                                  & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                  ? 1U
                                                  : 2U)) 
                                         & (3U == (3U 
                                                   & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                       << 0x10U) 
                                                      | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                         >> 0x10U))))))))
                           : ((1U & (((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                       >> 0x1cU) & 
                                      ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                        >> 0x1dU) & 
                                       (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                        >> 0x1eU))) 
                                     & (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x89U] 
                                        >> 3U))) ? 
                              (2U == ((0x1000000U & 
                                       vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                       ? 1U : 2U)) : 
                              ((3U == (3U & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                              << 0x10U) 
                                             | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                >> 0x10U))))
                                ? ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x89U] 
                                    >> 3U) & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                              >> 0xfU))
                                : ((~ (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x89U] 
                                       >> 3U)) & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                  >> 0xfU))))) 
                         << 0xfU)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all 
        = (0xfffeU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all 
        = ((0xfffeU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all)) 
           | (1U & ((0x100U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U])
                     ? (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq)
                     : ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                         >> 7U) & (((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                    | (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt)) 
                                   & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt))))));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all 
        = (0xfffdU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all 
        = ((0xfffdU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all)) 
           | (2U & (((0x10000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U])
                      ? ((0x8000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U])
                          ? ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                             >> 1U) : ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                       >> 1U)) : ((
                                                   vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                                   >> 0xfU) 
                                                  & ((((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                                       | (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt)) 
                                                      & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt)) 
                                                     >> 1U))) 
                    << 1U)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all 
        = (0xfffbU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all 
        = ((0xfffbU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all)) 
           | (4U & (((0x1000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U])
                      ? ((0x800000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U])
                          ? ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                             >> 2U) : ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                       >> 2U)) : ((
                                                   vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                                   >> 0x17U) 
                                                  & ((((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                                       | (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt)) 
                                                      & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt)) 
                                                     >> 2U))) 
                    << 2U)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all 
        = (0xfff7U & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all 
        = ((0xfff7U & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all)) 
           | (8U & (((1U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U])
                      ? ((0x80000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U])
                          ? ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                             >> 3U) : ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                       >> 3U)) : ((
                                                   vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                                   >> 0x1fU) 
                                                  & ((((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                                       | (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt)) 
                                                      & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt)) 
                                                     >> 3U))) 
                    << 3U)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all 
        = (0xffefU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all 
        = ((0xffefU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all)) 
           | (0x10U & (((0x100U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U])
                         ? ((0x80U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U])
                             ? ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                >> 4U) : ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                          >> 4U)) : 
                        ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                          >> 7U) & ((((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                      | (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt)) 
                                     & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt)) 
                                    >> 4U))) << 4U)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all 
        = (0xffdfU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all 
        = ((0xffdfU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all)) 
           | (0x20U & (((0x10000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U])
                         ? ((0x8000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U])
                             ? ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                >> 5U) : ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                          >> 5U)) : 
                        ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                          >> 0xfU) & ((((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                        | (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt)) 
                                       & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt)) 
                                      >> 5U))) << 5U)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all 
        = (0xffbfU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all 
        = ((0xffbfU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all)) 
           | (0x40U & (((0x1000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U])
                         ? ((0x800000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U])
                             ? ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                >> 6U) : ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                          >> 6U)) : 
                        ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                          >> 0x17U) & ((((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                         | (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt)) 
                                        & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt)) 
                                       >> 6U))) << 6U)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all 
        = (0xff7fU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all 
        = ((0xff7fU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all)) 
           | (0x80U & (((1U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U])
                         ? ((0x80000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U])
                             ? ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                >> 7U) : ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                          >> 7U)) : 
                        ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                          >> 0x1fU) & ((((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                         | (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt)) 
                                        & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt)) 
                                       >> 7U))) << 7U)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all 
        = (0xfeffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all 
        = ((0xfeffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all)) 
           | (0x100U & (((0x100U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U])
                          ? ((0x80U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U])
                              ? ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                 >> 8U) : ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                           >> 8U)) : 
                         ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                           >> 7U) & ((((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                       | (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt)) 
                                      & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt)) 
                                     >> 8U))) << 8U)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all 
        = (0xfdffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all 
        = ((0xfdffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all)) 
           | (0x200U & (((0x10000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U])
                          ? ((0x8000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U])
                              ? ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                 >> 9U) : ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                           >> 9U)) : 
                         ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                           >> 0xfU) & ((((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                         | (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt)) 
                                        & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt)) 
                                       >> 9U))) << 9U)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all 
        = (0xfbffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all 
        = ((0xfbffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all)) 
           | (0x400U & (((0x1000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U])
                          ? ((0x800000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U])
                              ? ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                 >> 0xaU) : ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                             >> 0xaU))
                          : ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                              >> 0x17U) & ((((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                             | (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt)) 
                                            & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt)) 
                                           >> 0xaU))) 
                        << 0xaU)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all 
        = (0xf7ffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all 
        = ((0xf7ffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all)) 
           | (0x800U & (((1U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U])
                          ? ((0x80000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U])
                              ? ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                 >> 0xbU) : ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                             >> 0xbU))
                          : ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                              >> 0x1fU) & ((((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                             | (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt)) 
                                            & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt)) 
                                           >> 0xbU))) 
                        << 0xbU)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all 
        = (0xefffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all 
        = ((0xefffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all)) 
           | (0x1000U & (((0x100U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U])
                           ? ((0x80U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U])
                               ? ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                  >> 0xcU) : ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                              >> 0xcU))
                           : ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                               >> 7U) & ((((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                           | (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt)) 
                                          & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt)) 
                                         >> 0xcU))) 
                         << 0xcU)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all 
        = (0xdfffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all 
        = ((0xdfffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all)) 
           | (0x2000U & (((0x10000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U])
                           ? ((0x8000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U])
                               ? ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                  >> 0xdU) : ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                              >> 0xdU))
                           : ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                               >> 0xfU) & ((((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                             | (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt)) 
                                            & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt)) 
                                           >> 0xdU))) 
                         << 0xdU)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all 
        = (0xbfffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all 
        = ((0xbfffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all)) 
           | (0x4000U & (((0x1000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U])
                           ? ((0x800000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U])
                               ? ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                  >> 0xeU) : ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                              >> 0xeU))
                           : ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                               >> 0x17U) & ((((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                              | (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt)) 
                                             & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt)) 
                                            >> 0xeU))) 
                         << 0xeU)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all 
        = (0x7fffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all 
        = ((0x7fffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all)) 
           | (0x8000U & (((1U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x89U])
                           ? ((0x80000000U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U])
                               ? ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                  >> 0xfU) : ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                              >> 0xfU))
                           : ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                               >> 0x1fU) & ((((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_eq) 
                                              | (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_gt)) 
                                             & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_lt)) 
                                            >> 0xfU))) 
                         << 0xfU)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all 
        = ((0xfffeU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all)) 
           | (1U & ((0x10U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x40U])
                     ? (~ (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check))
                     : ((3U == (3U & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                       << 0x10U) | 
                                      (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                       >> 0x10U))))
                         ? ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                             >> 0xbU) & (~ (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check)))
                         : (~ (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check))))));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all 
        = ((0xfffdU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all)) 
           | (2U & (((0x10U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x40U])
                      ? (~ ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check) 
                            >> 1U)) : ((3U == (3U & 
                                               ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                 << 0x10U) 
                                                | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                   >> 0x10U))))
                                        ? ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                            >> 0x13U) 
                                           & (~ ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                 >> 1U)))
                                        : (~ ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                              >> 1U)))) 
                    << 1U)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all 
        = ((0xfffbU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all)) 
           | (4U & (((0x10U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x40U])
                      ? (~ ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check) 
                            >> 2U)) : ((3U == (3U & 
                                               ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                 << 0x10U) 
                                                | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                   >> 0x10U))))
                                        ? ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x85U] 
                                            >> 0x1bU) 
                                           & (~ ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                 >> 2U)))
                                        : (~ ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                              >> 2U)))) 
                    << 2U)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all 
        = ((0xfff7U & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all)) 
           | (8U & (((0x10U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x40U])
                      ? (~ ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check) 
                            >> 3U)) : ((3U == (3U & 
                                               ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                 << 0x10U) 
                                                | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                   >> 0x10U))))
                                        ? ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                            >> 3U) 
                                           & (~ ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                 >> 3U)))
                                        : (~ ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                              >> 3U)))) 
                    << 3U)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all 
        = ((0xffefU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all)) 
           | (0x10U & (((0x10U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x40U])
                         ? (~ ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check) 
                               >> 4U)) : ((3U == (3U 
                                                  & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                      << 0x10U) 
                                                     | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                        >> 0x10U))))
                                           ? ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                               >> 0xbU) 
                                              & (~ 
                                                 ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                  >> 4U)))
                                           : (~ ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                 >> 4U)))) 
                       << 4U)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all 
        = ((0xffdfU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all)) 
           | (0x20U & (((0x10U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x40U])
                         ? (~ ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check) 
                               >> 5U)) : ((3U == (3U 
                                                  & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                      << 0x10U) 
                                                     | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                        >> 0x10U))))
                                           ? ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                               >> 0x13U) 
                                              & (~ 
                                                 ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                  >> 5U)))
                                           : (~ ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                 >> 5U)))) 
                       << 5U)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all 
        = ((0xffbfU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all)) 
           | (0x40U & (((0x10U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x40U])
                         ? (~ ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check) 
                               >> 6U)) : ((3U == (3U 
                                                  & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                      << 0x10U) 
                                                     | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                        >> 0x10U))))
                                           ? ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x86U] 
                                               >> 0x1bU) 
                                              & (~ 
                                                 ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                  >> 6U)))
                                           : (~ ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                 >> 6U)))) 
                       << 6U)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all 
        = ((0xff7fU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all)) 
           | (0x80U & (((0x10U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x40U])
                         ? (~ ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check) 
                               >> 7U)) : ((3U == (3U 
                                                  & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                      << 0x10U) 
                                                     | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                        >> 0x10U))))
                                           ? ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                               >> 3U) 
                                              & (~ 
                                                 ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                  >> 7U)))
                                           : (~ ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                 >> 7U)))) 
                       << 7U)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all 
        = ((0xfeffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all)) 
           | (0x100U & (((0x10U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x40U])
                          ? (~ ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check) 
                                >> 8U)) : ((3U == (3U 
                                                   & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                       << 0x10U) 
                                                      | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                         >> 0x10U))))
                                            ? ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                                >> 0xbU) 
                                               & (~ 
                                                  ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                   >> 8U)))
                                            : (~ ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                  >> 8U)))) 
                        << 8U)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all 
        = ((0xfdffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all)) 
           | (0x200U & (((0x10U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x40U])
                          ? (~ ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check) 
                                >> 9U)) : ((3U == (3U 
                                                   & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                       << 0x10U) 
                                                      | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                         >> 0x10U))))
                                            ? ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                                >> 0x13U) 
                                               & (~ 
                                                  ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                   >> 9U)))
                                            : (~ ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                  >> 9U)))) 
                        << 9U)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all 
        = ((0xfbffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all)) 
           | (0x400U & (((0x10U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x40U])
                          ? (~ ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check) 
                                >> 0xaU)) : ((3U == 
                                              (3U & 
                                               ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                 << 0x10U) 
                                                | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                   >> 0x10U))))
                                              ? ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x87U] 
                                                  >> 0x1bU) 
                                                 & (~ 
                                                    ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                     >> 0xaU)))
                                              : (~ 
                                                 ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                  >> 0xaU)))) 
                        << 0xaU)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all 
        = ((0xf7ffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all)) 
           | (0x800U & (((0x10U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x40U])
                          ? (~ ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check) 
                                >> 0xbU)) : ((3U == 
                                              (3U & 
                                               ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                 << 0x10U) 
                                                | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                   >> 0x10U))))
                                              ? ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                                  >> 3U) 
                                                 & (~ 
                                                    ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                     >> 0xbU)))
                                              : (~ 
                                                 ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                  >> 0xbU)))) 
                        << 0xbU)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all 
        = ((0xefffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all)) 
           | (0x1000U & (((0x10U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x40U])
                           ? (~ ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check) 
                                 >> 0xcU)) : ((3U == 
                                               (3U 
                                                & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                    << 0x10U) 
                                                   | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                      >> 0x10U))))
                                               ? ((
                                                   vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                                   >> 0xbU) 
                                                  & (~ 
                                                     ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                      >> 0xcU)))
                                               : (~ 
                                                  ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                   >> 0xcU)))) 
                         << 0xcU)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all 
        = ((0xdfffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all)) 
           | (0x2000U & (((0x10U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x40U])
                           ? (~ ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check) 
                                 >> 0xdU)) : ((3U == 
                                               (3U 
                                                & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                    << 0x10U) 
                                                   | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                      >> 0x10U))))
                                               ? ((
                                                   vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                                   >> 0x13U) 
                                                  & (~ 
                                                     ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                      >> 0xdU)))
                                               : (~ 
                                                  ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                   >> 0xdU)))) 
                         << 0xdU)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all 
        = ((0xbfffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all)) 
           | (0x4000U & (((0x10U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x40U])
                           ? (~ ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check) 
                                 >> 0xeU)) : ((3U == 
                                               (3U 
                                                & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                    << 0x10U) 
                                                   | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                      >> 0x10U))))
                                               ? ((
                                                   vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x88U] 
                                                   >> 0x1bU) 
                                                  & (~ 
                                                     ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                      >> 0xeU)))
                                               : (~ 
                                                  ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                   >> 0xeU)))) 
                         << 0xeU)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all 
        = ((0x7fffU & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all)) 
           | (0x8000U & (((0x10U & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x40U])
                           ? (~ ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_mml_perm_check) 
                                 >> 0xfU)) : ((3U == 
                                               (3U 
                                                & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                                    << 0x10U) 
                                                   | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                                      >> 0x10U))))
                                               ? ((
                                                   vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x89U] 
                                                   >> 3U) 
                                                  & (~ 
                                                     ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                      >> 0xfU)))
                                               : (~ 
                                                  ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_basic_perm_check) 
                                                   >> 0xfU)))) 
                         << 0xfU)));
    this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault 
        = (1U & ((3U != (3U & ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U] 
                                << 0x10U) | (vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[0U] 
                                             >> 0x10U)))) 
                 | ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x40U] 
                     >> 5U) | ((vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__csr_pmp[0x40U] 
                                >> 4U) & (0U == ((0x1000000U 
                                                  & vlTOPp->uCup_top__DOT__genblk1__DOT__u_soc__DOT__u_core__DOT__u_incore__DOT__load_store_unit_i__DOT__wpt_trans[1U])
                                                  ? 1U
                                                  : 2U))))));
    if ((0x8000U & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all))) {
        this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault 
            = (1U & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all) 
                     >> 0xfU));
    }
    if ((0x4000U & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all))) {
        this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault 
            = (1U & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all) 
                     >> 0xeU));
    }
    if ((0x2000U & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all))) {
        this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault 
            = (1U & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all) 
                     >> 0xdU));
    }
    if ((0x1000U & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all))) {
        this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault 
            = (1U & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all) 
                     >> 0xcU));
    }
    if ((0x800U & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all))) {
        this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault 
            = (1U & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all) 
                     >> 0xbU));
    }
    if ((0x400U & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all))) {
        this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault 
            = (1U & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all) 
                     >> 0xaU));
    }
    if ((0x200U & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all))) {
        this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault 
            = (1U & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all) 
                     >> 9U));
    }
    if ((0x100U & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all))) {
        this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault 
            = (1U & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all) 
                     >> 8U));
    }
    if ((0x80U & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all))) {
        this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault 
            = (1U & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all) 
                     >> 7U));
    }
    if ((0x40U & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all))) {
        this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault 
            = (1U & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all) 
                     >> 6U));
    }
    if ((0x20U & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all))) {
        this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault 
            = (1U & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all) 
                     >> 5U));
    }
    if ((0x10U & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all))) {
        this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault 
            = (1U & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all) 
                     >> 4U));
    }
    if ((8U & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all))) {
        this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault 
            = (1U & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all) 
                     >> 3U));
    }
    if ((4U & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all))) {
        this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault 
            = (1U & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all) 
                     >> 2U));
    }
    if ((2U & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all))) {
        this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault 
            = (1U & ((IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all) 
                     >> 1U));
    }
    if ((1U & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__region_match_all))) {
        this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault 
            = (1U & (IData)(this->__PVT__pmp_trie__DOT__locked_pmp_i__DOT__access_fault_all));
    }
}
